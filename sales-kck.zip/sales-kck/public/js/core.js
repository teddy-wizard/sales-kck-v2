function normalizeCost(cost){
    return parseFloat(cost).toFixed(2);
}
