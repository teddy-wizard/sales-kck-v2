<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row m-b-30">
            <div class="col-lg-12">
                <a class="btn btn-primary pull-right" href="<?php echo e(route('user.create')); ?>"><i class="fa fa-plus"></i>&nbsp; Create User</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table table-borderless table-striped table-earning js-exportable">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Login ID</th>
                            <th>Name</th>
                            <th>Email Address</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($user->username); ?></td>
                            <td>
                                <?php echo e($user->name); ?>

                            </td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php if($user->status == 0): ?> Inactive <?php endif; ?>
                                <?php if($user->status == 1): ?> Active <?php endif; ?>
                                <?php if($user->status == 2): ?> Locked <?php endif; ?>
                                <?php if($user->status == 3): ?> Deactivated <?php endif; ?>
                            </td>
                            <td>
                                <div class="table-data-feature text-center">
                                    <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                        <i class="zmdi zmdi-edit"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Project\sales-kck\sales-kck\resources\views/main/user/index.blade.php ENDPATH**/ ?>