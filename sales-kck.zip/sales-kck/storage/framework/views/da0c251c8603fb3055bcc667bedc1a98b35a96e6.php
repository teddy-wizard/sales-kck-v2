<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row m-b-30">
            <div class="col-lg-12">
                <div class="card p-5">
                    <div class="form-group col-md-6">
                        <label for="status" class="control-label mb-1">Data*</label>
                        <select id="type" name="type" class="form-control">
                            <option value=""> ----- Select ----- </option>
                            <option value="SalesAgent">SalesAgent</option>
                            <option value="TaxType">TaxType</option>
                            <option value="Term">Term</option>
                            <option value="StockItem">StockItem</option>
                            <option value="Debtor">Debtor</option>
                            <option value="SalesOrder">SalesOrder</option>
                            <option value="Invoice">Invoice</option>
                            <option value="DebitNote">DebitNote</option>
                            <option value="SalesInvoice">SalesInvoice</option>
                            <option value="SalesCreditNote">SalesCreditNote</option>
                            <option value="SalesDebitNote">SalesDebitNote</option>
                        </select>
                    </div>
                    <button id="btnSync" class="btn btn-primary pull-left"><i class="fa fa-cloud"></i>&nbsp; Sync Data</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){
            $("#btnSync").on("click", function(){

                if($("#type").val() == "")
                    return;


                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('syncData')); ?>",
                    data: {
                        'option' : $("#type").val(),
                        '_token': '<?php echo e(csrf_token()); ?>'
                    },
                    success:function(data) {
                        console.log(data.result);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Project\sales-kck\sales-kck\resources\views/main/sync/index.blade.php ENDPATH**/ ?>