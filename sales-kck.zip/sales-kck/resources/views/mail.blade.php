<h1>Hi, {{ $username }}</h1>
<p>Reset password request from KCK Sales App</p>
<p>New Password : {{ $password }}</p>
