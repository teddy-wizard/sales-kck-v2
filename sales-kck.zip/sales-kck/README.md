# sales-kck


# command
1. composer install
2. env file 
    If not application key, generate it
    php artisan key:generate

3. migration 

     php artisan migrate
     php artisan db:seed


# SSH access to server
sudo ssh -i C17449-SS0007501.pem almalinux@118.107.242.141

# Cpanel Install Guide
https://docs.cpanel.net/installation-guide/system-requirements-almalinux/

