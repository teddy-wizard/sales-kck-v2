<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataSyncApi extends Model
{
    //
}
