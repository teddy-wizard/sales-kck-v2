<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MsSalesArea extends Model
{
    //
}
