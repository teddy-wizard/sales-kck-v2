<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RptCategoryMapping extends Model
{
    //
}
