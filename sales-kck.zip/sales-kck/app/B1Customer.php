<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class B1Customer extends Model
{
    //
}
