<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class B1ItemUom extends Model
{
    //
}
