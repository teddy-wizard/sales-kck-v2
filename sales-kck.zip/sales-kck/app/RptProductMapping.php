<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RptProductMapping extends Model
{
    //
}
