<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AcSalesCreditNoteDtl extends Model
{
    //
}
