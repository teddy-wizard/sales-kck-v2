<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class B1TaxType extends Model
{
    //
}
