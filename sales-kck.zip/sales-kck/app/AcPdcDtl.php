<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AcPdcDtl extends Model
{
    //
}
