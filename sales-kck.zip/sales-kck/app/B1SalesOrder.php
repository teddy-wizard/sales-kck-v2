<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class B1SalesOrder extends Model
{
    //
}
