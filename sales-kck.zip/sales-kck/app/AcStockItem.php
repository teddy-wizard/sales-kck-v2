<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AcStockItem extends Model
{
    //
}
