<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AcPdcKnockoffDtl extends Model
{
    //
}
